library(shiny)
library(ggplot2)
library(dplyr)
library(plotly)
library(factoextra)
library(tidyr)
library(tidyverse)
library(shinydashboard)
library(shinyjs)
library(DT)
library(wordcloud)
library(RColorBrewer)

cluster_1 <- read_csv("clusters_1.csv")
cluster_2 <- read_csv('clusters_2.csv')
cluster_3 <- read_csv('clusters_3.csv')

performance_1 <- read_csv('performance_1.csv')
performance_2 <- read_csv('performance_2.csv')
performance_3 <- read_csv('performance_3.csv')

cluster_1$cluster_type = 'cluster_1'
cluster_2$cluster_type = 'cluster_2'
cluster_3$cluster_type = 'cluster_3'

performance_1$performance_type = 'performance_1'
performance_2$performance_type = 'performance_2'
performance_3$performance_type = 'performance_3'

performance <- performance_1 %>% rbind(performance_2) %>% rbind(performance_3)

clusters <- cluster_1 %>% rbind(cluster_2) %>% rbind(cluster_3)

df <- left_join(performance,clusters,by='symbol',relationship='many-to-many') %>%
  mutate(cluster=as.factor(cluster),
         Performance=ifelse(Excess_Return<=0,'underperformed',
                            'overperformed')) %>%
  filter(cluster != 4) %>% na.omit()


df_long <- df%>%
  pivot_longer(cols=c(Excess_Return,Beta,Sharpe_Ratio)) %>% filter(cluster != 4)

tsclust_obj <- readRDS("tsclust_obj.rds")
avg_cluster_long_1 <- read.csv("avg_cluster_long_1.csv")
avg_cluster_long_1$Date <- as.Date(avg_cluster_long_1$Date)

autocorrelations <- read.csv("autocorrelations.csv")
auto_kmeans_result <- readRDS("auto_kmeans_result.rds")

avg_cluster_long_2 <- read.csv("avg_cluster_long_2.csv")
avg_cluster_long_2$Date <- as.Date(avg_cluster_long_2$Date)

clustering_result <- readRDS("dtw_kmeans.rds")
dtw_kmeans_clusters <- clustering_result@cluster
dtw_ts_data_df <- read_csv("dtw_ts_data_df.csv")

avg_cluster_long_3 <- read.csv("avg_cluster_long_3.csv")
avg_cluster_long_3$Date <- as.Date(avg_cluster_long_3$Date)


ui <- dashboardPage(
  dashboardHeader(),
  dashboardSidebar(
    selectInput(
      inputId = "cluster_type",
      label = "Cluster type",
      choices = c("DTW hierarchical" = "cluster_1",
                  "Autocorrelation k-means" = "cluster_2",
                  "DTW k-means" = "cluster_3")
    ),
    selectInput(
      inputId = "y_var",
      label = "Y-axis variable",
      choices = c("Excess_Return", "Beta", "Sharpe_Ratio"),
      multiple = TRUE,
      selected = c("Excess_Return", "Beta", "Sharpe_Ratio")
    )
  ),
  dashboardBody(
    useShinyjs(),
    tags$head(
      tags$style(
        HTML("
          .main-sidebar {
            position: fixed;
          }
          .skin-blue .main-header .logo {
            background-color: #333;
          }
          .skin-blue .main-header .navbar {
            background-color: #555;
          }
        ")
      )
    ),
    fluidRow(
      conditionalPanel(
        condition = "input.cluster_type == 'cluster_1'",
        box(
          width = 6,
          title = "Dendrogram",
          plotOutput("dendrogram_plot")
        ),
        box(
          width = 6,
          title = "Line Chart",
          plotlyOutput("line_plot")
        )
      ),
      conditionalPanel(
        condition = "input.cluster_type == 'cluster_2'",
        box(
          width = 6,
          title = "K-means with autocorrelations",
          plotOutput("auto_fviz")
        ),
        box(
          width = 6,
          title = "Line chart",
          plotlyOutput("line_plot_2")
        )
      ),
      conditionalPanel(
        condition = "input.cluster_type == 'cluster_3'",
        box(
          width = 6,
          title = "K-means with DTW",
          plotOutput("auto_fviz_2")
        ),
        box(
          width = 6,
          title = "Line chart",
          plotlyOutput("line_plot_3")
        )
      ),
      box(
        width = 12,
        title = "Boxplots",
        plotlyOutput("box_plot")
      ),
      box(
        width = 12,
        title = "Barplots",
        plotlyOutput("bar_plot")
      ),
      fluidRow(
        column(
          width = 8,
          box(
            title = "Table",
            status = "primary",
            solidHeader = TRUE,
            width = 12,
            checkboxGroupInput(
              inline = T,
              inputId = "cluster",
              label = "Select Cluster:",
              choices = unique(df$cluster),
              selected = 1
            ),
            DT::dataTableOutput("table_1")
          )
        ),
        column(
          width = 4,
          box(
            title = "Word Cloud",
            status = "info",
            solidHeader = TRUE,
            width = 12,
            plotOutput("word_cloud", height = "542px")
          )
        )
      )
    )
  )
)


server <- function(input, output, session) {
  
  output$dendrogram_plot <- renderPlot({
    plot(tsclust_obj, hang=-1, cex=0.6)
  })
  
  output$line_plot <- renderPlotly({
    avg_cluster_long_1 %>%
      filter(Cluster != "Cluster4") %>%
      ggplot(aes(x=Date,y=Value,color=Cluster)) +
      geom_line() + theme_minimal()
  })
  
  output$auto_fviz <- renderPlot({
    fviz_cluster(auto_kmeans_result, autocorrelations[,-1], geom="point")+theme_minimal()+
      theme(legend.position="bottom")
  })
  
  output$auto_fviz_2 <- renderPlot({
    fviz_cluster(list(data=dtw_ts_data_df, cluster=dtw_kmeans_clusters), geom="point")+
      theme_minimal() + theme(legend.position="bottom")
  })
  
  output$line_plot_2 <- renderPlotly({
    avg_cluster_long_2 %>%
      ggplot(aes(x=Date,y=Value,color=Cluster)) +
      geom_line() + theme_minimal()
  })
  
  output$line_plot_3 <- renderPlotly({
    avg_cluster_long_3 %>%
      ggplot(aes(x=Date,y=Value,color=Cluster)) +
      geom_line() + theme_minimal()
  })
  
  output$box_plot <- renderPlotly({
    df_long %>%
      filter(cluster_type == input$cluster_type,
             name %in% input$y_var) %>%
      ggplot(aes(y=value,x=cluster,color=cluster)) +
      geom_boxplot() +
      facet_grid(performance_type ~ name, scales="free") +
      ggtitle("Boxplots of numeric variables by clusters")+
      coord_flip() + theme_minimal()
  })
  
  output$bar_plot <- renderPlotly({
    df %>%
      filter(cluster_type == input$cluster_type,
             cluster != 4) %>%
      group_by(performance_type, cluster, Performance) %>%
      summarise(count = n()) %>%
      mutate(percentage = count / sum(count)) %>%
      ggplot(aes(x=cluster,y=count,fill=Performance)) +
      geom_col(position="dodge") +
      geom_text(
        aes(label=paste0(round(percentage*100),"%")),
        position=position_dodge(width=0.9),
        vjust=-0.5
      ) +
      facet_wrap(~performance_type) +
      ggtitle("Distributions of performance in clusters") +
      theme_minimal() +
      theme(legend.position="bottom")+
      scale_fill_manual(values=c("#008000", "#FF1030"))
  })
  
  output$table_1 <- DT::renderDataTable({
    req(input$cluster)
    filtered_df <- df %>%
      filter(cluster %in% input$cluster & performance_type == "performance_1"
             & cluster_type == input$cluster_type) %>%
      select(-c("cluster_type", "performance_type")) %>%
      arrange(desc(Excess_Return))
    
    if (nrow(filtered_df) == 0) {
      DT::datatable(data.frame(), options = list(searching = FALSE))
    } else {
      DT::datatable(filtered_df)
    }
  })
  
  filtered_data <- reactive({
    req(input$cluster)
    df %>%
      filter(cluster %in% input$cluster & performance_type == "performance_1"
             & cluster_type == input$cluster_type) %>%
      select(symbol, Excess_Return) %>%
      group_by(symbol) %>%
      summarize(freq = sum(Excess_Return), .groups = "drop")
  })
  
  output$word_cloud <- renderPlot({
    req(filtered_data())
    
    if (nrow(filtered_data()) == 0) {
      plot(0, 0, type = "n", xlab = "", ylab = "", xlim = c(-1, 1), ylim = c(-1, 1))
      text(0, 0, "No data available", cex = 1.2)
    } else {
      wordcloud::wordcloud(
        words = filtered_data()$symbol,
        freq = filtered_data()$freq,
        min.freq = 0,
        scale = c(6, 1.5),
        colors = brewer.pal(8, "Dark2")
      )
    }
  })
}

shinyApp(ui, server)